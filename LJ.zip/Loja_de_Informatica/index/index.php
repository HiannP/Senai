<?php
	$sql = "SELECT * FROM Produtos_tb";
	include "conexao.php";
	$cadastro = $conn -> prepare($sql);
	$cadastro -> execute();
	$conn = null;
?>

<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <title>index</title>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="index style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  </head>
  <body>
		<header>
			<div><h1>GABINETEC</h1> <a href="login.php"><i class="fa fa-user-circle-o"></i></a> </div>
			<input class="search" type="text" placeholder="Pesquisa (Nome; Modelo; Cor; etc...)">
		</header> 
		<br>
		
		<?php
			foreach($cadastro as $cad) {
				
				$desc = $cad['descricao'];
				$valor = $cad['valor_unit'];
				$fab = $cad['fabricante'];
				$img = $cad['img'];
				
				echo "<fieldset>";
				echo "<img src='imge/$img.jpg' width='250px' height='250px'>";
				echo "<br>";
				echo "$desc";
				echo "<br>";
				echo "$fab";
				echo "<br>";
				echo "R$$valor";
				echo "</fieldset>";
			}
		?> 
		<br>
	
		<footer>
		 <br> <p>© 2021 de GABINETEC. Todos os direitos reservados.</p> <br>
		</footer>
		
  </body>
</html>