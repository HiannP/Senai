<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <title>Login</title>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="index style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide">
  </head>
  <body>
		<header>
			<h1>GABINETEC</h1>
		</header>
		<br>
		<fieldset>
			<form action="login2.php" method="POST">
			<label>Email:</label><br>
			<input type="email" id="email" name="email"> <br>
			
			<label>Senha:</label><br>
			<input type="text" class="senha" name="senha"> <br>
			
			<label>Cofirmar Senha:</label><br>
			<input type="text" class="senha" name="senha"> <br><br>
	
			<input type="submit" value="Submit">
			</form> 
		</fieldset>
		<br>
		<footer>
		 <br> <p>© 2021 de GABINETEC. Todos os direitos reservados.</p> <br>
		</footer>
		
  </body>
</html>